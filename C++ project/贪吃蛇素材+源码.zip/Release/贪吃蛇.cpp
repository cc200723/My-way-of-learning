#include<graphics.h>
#include<stdio.h>
#include<conio.h>
#include<time.h>
#define wide 500
#define height 600
#define MAX 100
#define NUM 10

int speed = 180;
int ss=0;
IMAGE img;
//��
struct mysnake
{
	POINT xy[MAX];
	char dir;
	int num;
}snake;
//mysnake snake[MAX];
//ʳ��
struct food
{
	POINT xy;
	int f;
	int num;
	int soc;
}food;
//����
enum{ right=77,left=75,up=72,down=80};

//��ʼ����
void GameInit()
{
	initgraph(wide, height);

	loadimage(&img, "timg.jpg");
	snake.dir = right;
	snake.num = 3;
	snake.xy[0].x = 140;
	snake.xy[0].y = 100;

	snake.xy[1].x = 120;
	snake.xy[1].y = 100;

	snake.xy[2].x = 100;
	snake.xy[2].y = 100;
	srand((unsigned int)time(NULL));
	food.f = 0;
	food.soc = 0;
}
//��ʼ��ʳ��
void InitFood()
{
	food.xy.x = rand() % 20 * 20+20;
	food.xy.y = rand() % 26 * 20+20;
	if (food.xy.x == snake.xy[0].x && food.xy.y == snake.xy[0].y)
	{
		food.xy.x = rand() % 20 * 20 + 20;
		food.xy.y = rand() % 26 * 20 + 20;
	}
	food.f = 1;
}
void DrawSnake()
{
	setlinecolor(YELLOW);
	for (int i = 0; i < snake.num; i++)
	{
		//
		if (i == 0)
		{
			setfillcolor(RED);
			fillrectangle(snake.xy[i].x, snake.xy[i].y, snake.xy[i].x + 20, snake.xy[i].y + 20);
		}
		else
		{
			setfillcolor(GREEN);
			
			fillrectangle(snake.xy[i].x, snake.xy[i].y, snake.xy[i].x + 20, snake.xy[i].y + 20);
		}
		
	}
	if (food.f == 1)
	{
		//setlinecolor(LIGHTGREEN);
		setfillcolor(RGB(rand() % 256, rand() % 256, rand() % 256));
		//setfillcolor(YELLOW);
		fillcircle((food.xy.x + 10), (food.xy.y + 10), 10);
	}
}

void MoveSnake()
{
	for (int i = snake.num; i>0; i--)
	{
		snake.xy[i].x = snake.xy[i - 1].x;
		snake.xy[i].y = snake.xy[i - 1].y;
	}
	switch (snake.dir)
	{
	case up:
		snake.xy[0].y -= 20;
		break;
	case down:
		snake.xy[0].y += 20;
		break;
	case left:
		snake.xy[0].x -= 20;
		break;
	case right:
		snake.xy[0].x += 20;
		break;
	}
}
void PlayGame()
{
	if (_kbhit())
	{
		char ch = _getch();
		if (ch == ' ')
		{
			while (_getch() != ' ');
		}
		switch (ch)
		{
		case 'w':
		case 'W':
		case 72:
			if (snake.dir != down)
				snake.dir = up;
			break;
		case 'S':
		case 's':
		case 80:
			if (snake.dir != up)
				snake.dir = down;
			break;
		case'a':
		case 'A':
		case 75:
			if (snake.dir != right)
				snake.dir = left;
			break;
		case'd':
		case 'D':
		case 77:
			if (snake.dir != left)
				snake.dir = right;
			break;
		}
		
	}
}
void GamePaint()
{

	setbkcolor(RGB(100,110,120));
	
	cleardevice();
	BeginBatchDraw();
	putimage(0, 0, &img);
	for (int i = 0; i < 25; i++)
	{
		setlinecolor(BLACK);
		line(i * 20, 0, i * 20, 560);
	}
	for (int j = 0; j < 28; j++)
	{
		line(0, j*20, 500, j*20);
	}
	char file[22] = { 0 };
	settextcolor(RED);
	settextstyle(20, 0, _T("����"));
	sprintf_s(file, _T("����:%d"), food.soc);
	char live[50] = {0};
	char sped[20] = "";
	sprintf_s(sped, _T(":%d"), speed);
	int m = 0;

	if (food.soc < 10)
	{
		m = 0;
		sprintf_s(live, _T(":%d"), m);
	}
	if (food.soc>=10 &&food.soc < 50)
	{
		m = 1;
		ss = 10;
		sprintf_s(live, _T(":%d"), m);
	}
	if (food.soc>=50 && food.soc < 100)
	{
		m = 2;
		ss = 50;
		sprintf_s(live, _T(":%d"), m);
	}
	if (food.soc >= 100)
	{
		m = 3;
		ss = 100;
		sprintf_s(live, _T(":%d"), m);
	}
	outtextxy(50, 570, live);
	outtextxy(10, 570, "�ȼ�:");
	outtextxy(100, 570, "��ǰ�ٶ�:");
	outtextxy(180, 570, sped);
	outtextxy(400, 570, file);
	DrawSnake();
	setlinecolor(RED);
	//line(0, 565, 500, 570-5);
	rectangle(1, 1, 500 - 1, 560);
	EndBatchDraw();
}
void EatFood()
{
	if (food.xy.x == snake.xy[0].x&&food.xy.y == snake.xy[0].y)
	{
		food.f = 0;
		snake.num++;
		food.soc += 5; speed--;
	}

}

int GameOver()
{
	if (snake.xy[0].x<0 || snake.xy[0].y<0 || snake.xy[0].x>500 - 20 || snake.xy[0].y>600 - 80)
	{
		settextcolor(RED);
		settextstyle(30, 0, _T("����"));
		outtextxy(150, 280, _T("��Ϸ������ײǽ��"));
		return 1;
	}
	for (int i = 1; i < snake.num; i++)
	{
		if (snake.xy[0].x == snake.xy[i].x && snake.xy[0].y == snake.xy[i].y)
		{		
			settextcolor(RED);
			settextstyle(30, 0, _T("����"));
			outtextxy(150, 280, _T("��Ϸ������ײ�Լ���"));
			return 1;
		}
 	}
	return 0;
}


int main()
{
	GameInit();
	DWORD t1 = GetTickCount(), t2;
	while (1)
	{
		GamePaint();
		t2 = GetTickCount();
		if (food.f == 0)
		{
			InitFood();
		}
		if (GameOver())
			break;
		PlayGame();
		EatFood();
		if (t2 - t1 > speed)
		{
			MoveSnake();
			t1 = t2;
		}
	}
	Sleep(1000);
	closegraph();
	return 0;
}